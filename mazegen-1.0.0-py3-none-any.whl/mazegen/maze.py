from enum import IntFlag
from typing import Annotated, TypeAlias
from pydantic import BaseModel, ConfigDict, Field, model_validator

Coordinate: TypeAlias = tuple[int, int]
Cell = Annotated[int, Field(ge=0, le=0xF)]


class Wall(IntFlag):
    """Represent the four walls surrounding a maze cell."""

    NORTH = 0b0001
    EAST = 0b0010
    SOUTH = 0b0100
    WEST = 0b1000
    ALL = NORTH | EAST | SOUTH | WEST


DIRECTIONS: dict[str, tuple[int, int, Wall, Wall]] = {
    "N": (0, -1, Wall.NORTH, Wall.SOUTH),
    "E": (1, 0, Wall.EAST, Wall.WEST),
    "S": (0, 1, Wall.SOUTH, Wall.NORTH),
    "W": (-1, 0, Wall.WEST, Wall.EAST),
}


class Maze(BaseModel):
    """Store an immutable, validated maze and its solved path."""

    model_config = ConfigDict(frozen=True)

    cells: tuple[tuple[Cell, ...], ...]
    entry: Coordinate
    exit: Coordinate
    solution: tuple[Coordinate, ...] = ()
    pattern_cells: tuple[Coordinate, ...]

    @property
    def width(self) -> int:
        """Return the maze width in cells."""
        return len(self.cells[0])

    @property
    def height(self) -> int:
        """Return the maze height in cells."""
        return len(self.cells)

    @model_validator(mode="after")
    def validate_maze(self) -> "Maze":
        """Validate grid shape and every stored coordinate."""
        if not self.cells or not self.cells[0]:
            raise ValueError("Maze must contain at least one cell")

        width = len(self.cells[0])

        if any(len(row) != width for row in self.cells):
            raise ValueError("All maze rows must have the same width")

        self._validate_coordinate("ENTRY", self.entry)
        self._validate_coordinate("EXIT", self.exit)

        for coordinate in self.solution:
            self._validate_coordinate("SOLUTION", coordinate)

        for coordinate in self.pattern_cells:
            self._validate_coordinate("PATTERN_CELL", coordinate)

        return self

    def _validate_coordinate(
        self,
        name: str,
        coordinate: Coordinate,
    ) -> None:
        """Raise an error when a coordinate lies outside the maze."""
        x, y = coordinate

        if not (0 <= x < self.width and 0 <= y < self.height):
            raise ValueError(f"{name} {coordinate} is outside the maze bounds")
